import os
import json
import random
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, CallbackQueryHandler, filters

# Папки
PHOTOS_FOLDER = 'photos'
DATA_FOLDER = 'data'

# Твой Telegram ID - замени на свой!
OWNER_ID = 8432547645  # int, например 123456789

# Создаем папки, если нет
os.makedirs(PHOTOS_FOLDER, exist_ok=True)
os.makedirs(DATA_FOLDER, exist_ok=True)

# Функция для загрузки данных для конкретного фото
def load_data_for_photo(photo_basename):
    file_path = os.path.join(DATA_FOLDER, f'{photo_basename}.json')
    if os.path.exists(file_path):
        with open(file_path, 'r') as f:
            return json.load(f)
    return {'ratings': [], 'comments': []}

# Сохранение данных для фото
def save_data_for_photo(photo_basename, data):
    file_path = os.path.join(DATA_FOLDER, f'{photo_basename}.json')
    with open(file_path, 'w') as f:
        json.dump(data, f, indent=4)

# Получить рандомное фото
def get_random_photo():
    photos = [f for f in os.listdir(PHOTOS_FOLDER) if f.lower().endswith(('.jpg', '.png'))]
    if not photos:
        return None
    return random.choice(photos)

# Показать фото и попросить оценку, с комментариями в caption
async def show_photo(update: Update, context, message=None):
    photo_file = get_random_photo()
    if not photo_file:
        await (message or update.message).reply_text('Нет фото в папке photos!')
        return
    photo_path = os.path.join(PHOTOS_FOLDER, photo_file)
    photo_basename = os.path.splitext(photo_file)[0]
    context.user_data['current_photo'] = photo_basename
    context.user_data['waiting_comment'] = False
    
    data = load_data_for_photo(photo_basename)
    comments_text = '\n\nАнонимные комментарии:\n' + '\n'.join(f'{i+1}. {comm}' for i, comm in enumerate(data['comments'])) if data['comments'] else ''
    
    caption = f'Напиши оценку от 1 до 10:{comments_text}'
    await (message or update.message).reply_photo(photo=open(photo_path, 'rb'), caption=caption)

# Старт
async def start(update: Update, context):
    await update.message.reply_text('Привет! Бот для анонимной оценки фото. Начинаем...\nТы можешь отправить свое фото - оно анонимно пойдет на проверку, и если одобрят, добавят в ротацию.')
    await show_photo(update, context)

# Обработка текстового сообщения (оценка или комментарий)
async def handle_message(update: Update, context):
    text = update.message.text.strip()
    if 'current_photo' not in context.user_data:
        await update.message.reply_text('Сначала нажми /start')
        return

    photo_basename = context.user_data['current_photo']
    data = load_data_for_photo(photo_basename)

    if context.user_data.get('waiting_comment', False):
        # Это комментарий
        data['comments'].append(text)
        save_data_for_photo(photo_basename, data)
        await update.message.reply_text('Комментарий сохранен анонимно!')
        context.user_data['waiting_comment'] = False
        await show_photo(update, context, update.message)
    else:
        # Это оценка
        try:
            score = int(text)
            if 1 <= score <= 10:
                data['ratings'].append(score)
                save_data_for_photo(photo_basename, data)
                avg = sum(data['ratings']) / len(data['ratings']) if data['ratings'] else 0
                reply_markup = InlineKeyboardMarkup([[
                    InlineKeyboardButton("Оставить комментарий", callback_data='add_comment'),
                    InlineKeyboardButton("Следующее фото", callback_data='next_photo')
                ]])
                await update.message.reply_text(f'Оценка сохранена! Средний балл для этого фото: {avg:.2f}', reply_markup=reply_markup)
            else:
                await update.message.reply_text('Оценка должна быть от 1 до 10!')
        except ValueError:
            await update.message.reply_text('Напиши число от 1 до 10 для оценки!')

# Обработка фото (анонимная загрузка)
async def handle_photo(update: Update, context):
    # Анонимно отправляем фото владельцу
    photo = update.message.photo[-1]  # Самое большое разрешение
    await context.bot.send_photo(chat_id=OWNER_ID, photo=photo.file_id, caption="New anonymous photo submission")
    await update.message.reply_text('Фото отправлено на анонимную проверку!')

# Обработка кнопок
async def button(update: Update, context):
    query = update.callback_query
    data = query.data
    await query.answer()

    photo_basename = context.user_data.get('current_photo')
    if not photo_basename:
        await query.edit_message_text('Ошибка, начни заново /start')
        return

    if data == 'add_comment':
        context.user_data['waiting_comment'] = True
        await query.edit_message_text('Теперь напиши комментарий:')
    elif data == 'next_photo':
        await show_photo(update, context, query.message)

def main():
    app = ApplicationBuilder().token('8430509426:AAH3Uc50SbbAfElwqZjNrIqemc7EMpmVJZY').build()

    app.add_handler(CommandHandler('start', start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    app.add_handler(CallbackQueryHandler(button))

    app.run_polling()

if __name__ == '__main__':
    main()